# ScamShield Extension — Install Guide

## Quick start (judges / testers)

### Step 1 — Start the backend
```bash
cd scamshield-ui
npm run dev
# → Ready on http://localhost:3000
```

### Step 2 — Load the extension
1. Open **Chrome** or **Edge**
2. Navigate to `chrome://extensions/`
3. Enable **Developer mode** (toggle, top-right)
4. Click **Load unpacked**
5. Select the `extension/` folder
6. Pin it: click 🧩 in the toolbar → pin **ScamShield**

### Step 3 — Verify connection
- Click the 🛡️ icon in your toolbar
- The dot next to the API URL should turn **green** (Connected)
- If it's red: make sure `npm run dev` is running and the URL is `http://localhost:3000`

### Step 4 — Try it

| Action | How |
|--------|-----|
| Check current page | Click **Analyze This Page** |
| Check highlighted text | Select text on any page → click **Analyze Selected Text** |
| Check via right-click | Select text → right-click → **Analyze with ScamShield** |
| Paste manually | Paste message or URL in the text box → **Analyze Pasted Text** |
| Switch persona | Click **Switch →** to cycle between Margaret / Ahmed / No Profile |
| Open full dashboard | Click **Open Full Dashboard →** at the bottom |

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Red dot (Offline) | Run `npm run dev` in the project folder |
| "Failed to analyze" | Check the API URL is `http://localhost:3000` and click Save |
| Extension not appearing | Re-check Developer mode is on, re-load unpacked |
| Page analysis fails | Some pages block scripting — use the paste box instead |

---

## Architecture

```
Browser Extension (popup.js)
        │
        │  POST /api/analyze
        ▼
ScamShield Next.js API (localhost:3000)
        │
        ├── Watsonx.ai (IBM Granite)  ← primary
        ├── Gemini Vision              ← images + fallback
        └── OpenAI                    ← last resort
```

All AI processing happens server-side. No API keys are stored in the extension.
